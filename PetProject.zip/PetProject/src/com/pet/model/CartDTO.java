package com.pet.model;

public class CartDTO {
	private int cart_no;
	private int cart_pno;
	private String cart_Id;
	private String cart_pname;
	private int cart_pqty;
	private int cart_price;
	private String cart_pspec;
	private String cart_pimage;
	private int cart_point;
	
	
	public int getCart_no() {
		return cart_no;
	}
	public void setCart_no(int cart_no) {
		this.cart_no = cart_no;
	}
	public int getCart_pno() {
		return cart_pno;
	}
	public void setCart_pno(int cart_pno) {
		this.cart_pno = cart_pno;
	}
	public String getCart_Id() {
		return cart_Id;
	}
	public void setCart_Id(String cart_Id) {
		this.cart_Id = cart_Id;
	}
	public String getCart_pname() {
		return cart_pname;
	}
	public void setCart_pname(String cart_pname) {
		this.cart_pname = cart_pname;
	}
	public int getCart_pqty() {
		return cart_pqty;
	}
	public void setCart_pqty(int cart_pqty) {
		this.cart_pqty = cart_pqty;
	}
	public int getCart_price() {
		return cart_price;
	}
	public void setCart_price(int cart_price) {
		this.cart_price = cart_price;
	}
	public String getCart_pspec() {
		return cart_pspec;
	}
	public void setCart_pspec(String cart_pspec) {
		this.cart_pspec = cart_pspec;
	}
	public String getCart_pimage() {
		return cart_pimage;
	}
	public void setCart_pimage(String cart_pimage) {
		this.cart_pimage = cart_pimage;
	}
	public int getCart_point() {
		return cart_point;
	}
	public void setCart_point(int cart_point) {
		this.cart_point = cart_point;
	}
	
	
	
	
}