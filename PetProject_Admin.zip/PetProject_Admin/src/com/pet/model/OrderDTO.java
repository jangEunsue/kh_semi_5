package com.pet.model;

public class OrderDTO {

	private int p_order_no;
	private int p_order_del;
	private int p_order_pay;
	
	public int getP_order_no() {
		return p_order_no;
	}
	public void setP_order_no(int p_order_no) {
		this.p_order_no = p_order_no;
	}
	public int getP_order_del() {
		return p_order_del;
	}
	public void setP_order_del(int p_order_del) {
		this.p_order_del = p_order_del;
	}
	public int getP_order_pay() {
		return p_order_pay;
	}
	public void setP_order_pay(int p_order_pay) {
		this.p_order_pay = p_order_pay;
	}
	
	
}
