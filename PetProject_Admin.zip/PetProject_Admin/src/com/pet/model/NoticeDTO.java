package com.pet.model;

public class NoticeDTO {

	private int notice_no;
	private String notice_writer;
	private String notice_title;
	private String notice_cont;
	private String notice_pwd;
	private int notice_hit;
	private String notice_date;
	private String notice_update;
	private int notice_group;
	private int notice_step;
	private int notice_indent;
	
	
	public int getNotice_no() {
		return notice_no;
	}
	public void setNotice_no(int notice_no) {
		this.notice_no = notice_no;
	}
	public String getNotice_writer() {
		return notice_writer;
	}
	public void setNotice_writer(String notice_writer) {
		this.notice_writer = notice_writer;
	}
	public String getNotice_title() {
		return notice_title;
	}
	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}
	public String getNotice_cont() {
		return notice_cont;
	}
	public void setNotice_cont(String notice_cont) {
		this.notice_cont = notice_cont;
	}
	public String getNotice_pwd() {
		return notice_pwd;
	}
	public void setNotice_pwd(String notice_pwd) {
		this.notice_pwd = notice_pwd;
	}
	public int getNotice_hit() {
		return notice_hit;
	}
	public void setNotice_hit(int notice_hit) {
		this.notice_hit = notice_hit;
	}
	public String getNotice_date() {
		return notice_date;
	}
	public void setNotice_date(String notice_date) {
		this.notice_date = notice_date;
	}
	public String getNotice_update() {
		return notice_update;
	}
	public void setNotice_update(String notice_update) {
		this.notice_update = notice_update;
	}
	public int getNotice_group() {
		return notice_group;
	}
	public void setNotice_group(int notice_group) {
		this.notice_group = notice_group;
	}
	public int getNotice_step() {
		return notice_step;
	}
	public void setNotice_step(int notice_step) {
		this.notice_step = notice_step;
	}
	public int getNotice_indent() {
		return notice_indent;
	}
	public void setNotice_indent(int notice_indent) {
		this.notice_indent = notice_indent;
	}
	
	
}
