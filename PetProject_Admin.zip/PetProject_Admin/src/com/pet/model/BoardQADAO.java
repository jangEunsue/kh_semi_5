package com.pet.model;

public class BoardQADAO {

}
