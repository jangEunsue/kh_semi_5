package com.pet.model;

public class SalesDTO {
	
	private int sales_no;
	private String sales_id;
	private int sales_serial;
	private String sales_name;
	private String sales_phone;
	private String sales_addr;
	private int sales_p_no;
	private String sales_pname;
	private String sales_pimage;
	private int sales_price;
	private int sales_pqty;
	private int sales_transcost;
	private String sales_payment;
	private String sales_comments;
	private int sales_mileage;
	private String sales_date;
	
	public int getSales_no() {
		return sales_no;
	}
	public void setSales_no(int sales_no) {
		this.sales_no = sales_no;
	}
	public String getSales_id() {
		return sales_id;
	}
	public void setSales_id(String sales_id) {
		this.sales_id = sales_id;
	}
	public int getSales_serial() {
		return sales_serial;
	}
	public void setSales_serial(int sales_serial) {
		this.sales_serial = sales_serial;
	}
	public String getSales_name() {
		return sales_name;
	}
	public void setSales_name(String sales_name) {
		this.sales_name = sales_name;
	}
	public String getSales_phone() {
		return sales_phone;
	}
	public void setSales_phone(String sales_phone) {
		this.sales_phone = sales_phone;
	}
	public String getSales_addr() {
		return sales_addr;
	}
	public void setSales_addr(String sales_addr) {
		this.sales_addr = sales_addr;
	}
	public int getSales_p_no() {
		return sales_p_no;
	}
	public void setSales_p_no(int sales_p_no) {
		this.sales_p_no = sales_p_no;
	}
	public String getSales_pname() {
		return sales_pname;
	}
	public void setSales_pname(String sales_pname) {
		this.sales_pname = sales_pname;
	}
	public String getSales_pimage() {
		return sales_pimage;
	}
	public void setSales_pimage(String sales_pimage) {
		this.sales_pimage = sales_pimage;
	}
	public int getSales_price() {
		return sales_price;
	}
	public void setSales_price(int sales_price) {
		this.sales_price = sales_price;
	}
	public int getSales_pqty() {
		return sales_pqty;
	}
	public void setSales_pqty(int sales_pqty) {
		this.sales_pqty = sales_pqty;
	}
	public int getSales_transcost() {
		return sales_transcost;
	}
	public void setSales_transcost(int sales_transcost) {
		this.sales_transcost = sales_transcost;
	}
	public String getSales_payment() {
		return sales_payment;
	}
	public void setSales_payment(String sales_payment) {
		this.sales_payment = sales_payment;
	}
	public String getSales_comments() {
		return sales_comments;
	}
	public void setSales_comments(String sales_comments) {
		this.sales_comments = sales_comments;
	}
	public int getSales_mileage() {
		return sales_mileage;
	}
	public void setSales_mileage(int sales_mileage) {
		this.sales_mileage = sales_mileage;
	}
	public String getSales_date() {
		return sales_date;
	}
	public void setSales_date(String sales_date) {
		this.sales_date = sales_date;
	}
	
	

}
