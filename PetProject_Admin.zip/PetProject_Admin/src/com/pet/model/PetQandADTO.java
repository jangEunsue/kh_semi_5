package com.pet.model;

public class PetQandADTO {
	private int QA_no;
    private String QA_writer;
    private String QA_title;
    private String QA_cont;
    private String QA_userID;
    private String QA_date;
    private String QA_update ;
    private int QA_group;
    private int QA_step;
    private int QA_indent;
    
	public int getQA_no() {
		return QA_no;
	}
	public void setQA_no(int qA_no) {
		QA_no = qA_no;
	}
	public String getQA_writer() {
		return QA_writer;
	}
	public void setQA_writer(String qA_writer) {
		QA_writer = qA_writer;
	}
	public String getQA_title() {
		return QA_title;
	}
	public void setQA_title(String qA_title) {
		QA_title = qA_title;
	}
	public String getQA_cont() {
		return QA_cont;
	}
	public void setQA_cont(String qA_cont) {
		QA_cont = qA_cont;
	}
	public String getQA_userID() {
		return QA_userID;
	}
	public void setQA_userID(String qA_userID) {
		QA_userID = qA_userID;
	}
	public String getQA_date() {
		return QA_date;
	}
	public void setQA_date(String qA_date) {
		QA_date = qA_date;
	}
	public String getQA_update() {
		return QA_update;
	}
	public void setQA_update(String qA_update) {
		QA_update = qA_update;
	}
	public int getQA_group() {
		return QA_group;
	}
	public void setQA_group(int qA_group) {
		QA_group = qA_group;
	}
	public int getQA_step() {
		return QA_step;
	}
	public void setQA_step(int qA_step) {
		QA_step = qA_step;
	}
	public int getQA_indent() {
		return QA_indent;
	}
	public void setQA_indent(int qA_indent) {
		QA_indent = qA_indent;
	}
    
    
}
